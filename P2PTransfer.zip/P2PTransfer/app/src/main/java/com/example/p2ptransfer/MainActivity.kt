/*
 * UI Jetpack Compose untuk NearbyTransfer.kt (letakkan di package yang sama).
 *
 * build.gradle (app), tambahan bila belum ada:
 *   implementation(platform("androidx.compose:compose-bom:2024.10.01"))
 *   implementation("androidx.compose.material3:material3")
 *   implementation("androidx.activity:activity-compose:1.9.3")
 */
package com.example.p2ptransfer

import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {

    private var transfer: NearbyTransfer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    TransferScreen()
                }
            }
        }
    }

    @Composable
    private fun TransferScreen() {
        val logs = remember { mutableStateListOf<String>() }
        var progress by remember { mutableIntStateOf(0) }
        var role by remember { mutableStateOf<String?>(null) } // "kirim" / "terima"
        var pickedUri by remember { mutableStateOf<Uri?>(null) }

        // Buat NearbyTransfer sekali saja
        val nt = remember {
            NearbyTransfer(
                context = applicationContext,
                deviceName = Build.MODEL ?: "Android",
                onEvent = { msg -> runOnUiThread { logs.add(0, msg) } },
                onProgress = { p -> runOnUiThread { progress = p } },
                onFileReceived = { f -> runOnUiThread { logs.add(0, "Tersimpan di: ${f.absolutePath}") } }
            ).also { transfer = it }
        }

        // Launcher untuk memilih file
        val filePicker = rememberLauncherForActivityResult(
            ActivityResultContracts.GetContent()
        ) { uri -> pickedUri = uri }

        // Launcher permission: setelah diizinkan, jalankan peran yang dipilih
        val permissionLauncher = rememberLauncherForActivityResult(
            ActivityResultContracts.RequestMultiplePermissions()
        ) { result ->
            if (result.values.all { it }) {
                when (role) {
                    "terima" -> nt.startReceiving()
                    "kirim" -> nt.startDiscovering()
                }
            } else {
                logs.add(0, "Permission ditolak, fitur tidak bisa dipakai")
            }
        }

        fun start(newRole: String) {
            role = newRole
            permissionLauncher.launch(NearbyTransfer.requiredPermissions())
        }

        Column(
            Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text("Transfer File P2P", style = MaterialTheme.typography.headlineSmall)

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = { start("terima") }, modifier = Modifier.weight(1f)) {
                    Text("Terima")
                }
                Button(onClick = { start("kirim") }, modifier = Modifier.weight(1f)) {
                    Text("Cari & Kirim")
                }
            }

            OutlinedButton(
                onClick = { filePicker.launch("*/*") },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text(if (pickedUri == null) "Pilih file" else "File dipilih, ganti?")
            }

            Button(
                onClick = { pickedUri?.let { nt.sendFile(it) } },
                enabled = pickedUri != null,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Kirim file")
            }

            if (progress in 1..99) {
                LinearProgressIndicator(
                    progress = { progress / 100f },
                    modifier = Modifier.fillMaxWidth()
                )
                Text("$progress%")
            }

            HorizontalDivider()

            LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(logs) { Text(it, style = MaterialTheme.typography.bodySmall) }
            }
        }
    }

    override fun onDestroy() {
        transfer?.stop()
        super.onDestroy()
    }
}
