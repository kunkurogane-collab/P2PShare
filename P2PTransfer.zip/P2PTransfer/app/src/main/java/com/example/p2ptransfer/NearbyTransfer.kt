/*
 * Transfer file P2P Android dengan Nearby Connections API.
 * Bluetooth dipakai untuk discovery, lalu otomatis naik ke Wi-Fi
 * (Wi-Fi Direct / hotspot) untuk file besar, tanpa memutus internet.
 *
 * build.gradle (app):
 *   implementation("com.google.android.gms:play-services-nearby:19.3.0")
 *
 * AndroidManifest.xml:
 *   <uses-permission android:name="android.permission.BLUETOOTH" android:maxSdkVersion="30"/>
 *   <uses-permission android:name="android.permission.BLUETOOTH_ADMIN" android:maxSdkVersion="30"/>
 *   <uses-permission android:name="android.permission.ACCESS_WIFI_STATE"/>
 *   <uses-permission android:name="android.permission.CHANGE_WIFI_STATE"/>
 *   <uses-permission android:name="android.permission.ACCESS_COARSE_LOCATION" android:maxSdkVersion="32"/>
 *   <uses-permission android:name="android.permission.ACCESS_FINE_LOCATION" android:maxSdkVersion="32"/>
 *   <uses-permission android:name="android.permission.BLUETOOTH_ADVERTISE"/>
 *   <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
 *   <uses-permission android:name="android.permission.BLUETOOTH_SCAN"/>
 *   <uses-permission android:name="android.permission.NEARBY_WIFI_DEVICES"
 *       android:usesPermissionFlags="neverForLocation"/>
 */
package com.example.p2ptransfer

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.OpenableColumns
import com.google.android.gms.nearby.Nearby
import com.google.android.gms.nearby.connection.*
import java.io.File

class NearbyTransfer(
    private val context: Context,
    private val deviceName: String,
    private val onEvent: (String) -> Unit,          // log / status untuk UI
    private val onProgress: (percent: Int) -> Unit, // progres transfer
    private val onFileReceived: (File) -> Unit
) {
    private val client = Nearby.getConnectionsClient(context)
    private val serviceId = "com.example.p2ptransfer"
    private val strategy = Strategy.P2P_POINT_TO_POINT

    private var endpointId: String? = null

    // Penerima: simpan payload file sampai transfer selesai
    private val incomingFiles = mutableMapOf<Long, Payload>()
    private val incomingNames = mutableMapOf<Long, String>()

    // ---------- Daftar permission runtime yang harus diminta ke user ----------
    companion object {
        fun requiredPermissions(): Array<String> = when {
            Build.VERSION.SDK_INT >= 33 -> arrayOf(
                android.Manifest.permission.BLUETOOTH_ADVERTISE,
                android.Manifest.permission.BLUETOOTH_CONNECT,
                android.Manifest.permission.BLUETOOTH_SCAN,
                android.Manifest.permission.NEARBY_WIFI_DEVICES
            )
            Build.VERSION.SDK_INT >= 31 -> arrayOf(
                android.Manifest.permission.BLUETOOTH_ADVERTISE,
                android.Manifest.permission.BLUETOOTH_CONNECT,
                android.Manifest.permission.BLUETOOTH_SCAN,
                android.Manifest.permission.ACCESS_FINE_LOCATION
            )
            else -> arrayOf(android.Manifest.permission.ACCESS_FINE_LOCATION)
        }
    }

    // ---------- Mulai sebagai penerima (advertise) ----------
    fun startReceiving() {
        val options = AdvertisingOptions.Builder().setStrategy(strategy).build()
        client.startAdvertising(deviceName, serviceId, connectionCallback, options)
            .addOnSuccessListener { onEvent("Menunggu pengirim...") }
            .addOnFailureListener { onEvent("Gagal advertise: ${it.message}") }
    }

    // ---------- Mulai sebagai pengirim (discover) ----------
    fun startDiscovering() {
        val options = DiscoveryOptions.Builder().setStrategy(strategy).build()
        client.startDiscovery(serviceId, discoveryCallback, options)
            .addOnSuccessListener { onEvent("Mencari perangkat...") }
            .addOnFailureListener { onEvent("Gagal discovery: ${it.message}") }
    }

    private val discoveryCallback = object : EndpointDiscoveryCallback() {
        override fun onEndpointFound(id: String, info: DiscoveredEndpointInfo) {
            onEvent("Ditemukan: ${info.endpointName}, menghubungkan...")
            client.requestConnection(deviceName, id, connectionCallback)
        }

        override fun onEndpointLost(id: String) {
            onEvent("Perangkat hilang dari jangkauan")
        }
    }

    private val connectionCallback = object : ConnectionLifecycleCallback() {
        override fun onConnectionInitiated(id: String, info: ConnectionInfo) {
            // info.authenticationDigits = kode 4 digit yang sama di kedua HP.
            // Tampilkan ke user untuk konfirmasi agar aman dari penyadap.
            onEvent("Kode verifikasi: ${info.authenticationDigits}")
            client.acceptConnection(id, payloadCallback)
        }

        override fun onConnectionResult(id: String, result: ConnectionResolution) {
            if (result.status.isSuccess) {
                endpointId = id
                client.stopDiscovery()
                client.stopAdvertising()
                onEvent("Terhubung")
            } else {
                onEvent("Koneksi gagal: ${result.status.statusMessage}")
            }
        }

        override fun onDisconnected(id: String) {
            endpointId = null
            onEvent("Terputus")
        }
    }

    // ---------- Kirim file ----------
    fun sendFile(uri: Uri) {
        val target = endpointId ?: return onEvent("Belum terhubung")

        val name = queryFileName(uri) ?: "file_${System.currentTimeMillis()}"
        val pfd = context.contentResolver.openFileDescriptor(uri, "r")
            ?: return onEvent("File tidak bisa dibuka")

        val filePayload = Payload.fromFile(pfd)

        // Kirim nama file lebih dulu lewat BYTES, formatnya: "<payloadId>:<nama>"
        val meta = "${filePayload.id}:$name".toByteArray(Charsets.UTF_8)
        client.sendPayload(target, Payload.fromBytes(meta))
        client.sendPayload(target, filePayload)
        onEvent("Mengirim $name ...")
    }

    private fun queryFileName(uri: Uri): String? =
        context.contentResolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) c.getString(idx) else null
        }

    // ---------- Terima payload & pantau progres ----------
    private val payloadCallback = object : PayloadCallback() {
        override fun onPayloadReceived(id: String, payload: Payload) {
            when (payload.type) {
                Payload.Type.BYTES -> {
                    val text = String(payload.asBytes()!!, Charsets.UTF_8)
                    val sep = text.indexOf(':')
                    if (sep > 0) {
                        val payloadId = text.substring(0, sep).toLongOrNull()
                        if (payloadId != null) incomingNames[payloadId] = text.substring(sep + 1)
                    }
                }
                Payload.Type.FILE -> incomingFiles[payload.id] = payload
                else -> {}
            }
        }

        override fun onPayloadTransferUpdate(id: String, update: PayloadTransferUpdate) {
            if (update.totalBytes > 0) {
                onProgress((update.bytesTransferred * 100 / update.totalBytes).toInt())
            }
            when (update.status) {
                PayloadTransferUpdate.Status.SUCCESS -> {
                    val payload = incomingFiles.remove(update.payloadId)
                    if (payload != null) saveReceivedFile(payload, update.payloadId)
                    else onEvent("Pengiriman selesai")
                }
                PayloadTransferUpdate.Status.FAILURE -> onEvent("Transfer gagal")
                PayloadTransferUpdate.Status.CANCELED -> onEvent("Transfer dibatalkan")
                else -> {}
            }
        }
    }

    // Salin file hasil terima dari lokasi sementara Nearby ke folder app
    private fun saveReceivedFile(payload: Payload, payloadId: Long) {
        val name = incomingNames.remove(payloadId) ?: "diterima_$payloadId"
        val src = payload.asFile()?.asUri() ?: return onEvent("File tidak ditemukan")

        val dest = File(context.getExternalFilesDir(null), name)
        context.contentResolver.openInputStream(src)?.use { input ->
            dest.outputStream().use { output -> input.copyTo(output) }
        }
        onEvent("Diterima: ${dest.name}")
        onFileReceived(dest)
    }

    // ---------- Bersihkan ----------
    fun stop() {
        client.stopAllEndpoints()
        client.stopAdvertising()
        client.stopDiscovery()
        endpointId = null
    }
}
